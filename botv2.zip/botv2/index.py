from selenium.common.exceptions import NoSuchElementException   
from selenium import webdriver
from selenium.webdriver.common.by import By
from discord.utils import get
from webdriver_manager.chrome import ChromeDriverManager
from itertools import repeat
import datetime
import discord
from datetime import datetime, timedelta
from pathlib import Path
import time
from discord_webhook import DiscordWebhook
from discord.ext import commands
import mysql.connector
import re
import os
import json
from discord import Member
from discord.ext.commands import has_permissions, MissingPermissions

WebhookURL = "https://discord.com/api/webhooks/988556491839647885/RTgNvPTAlTXiOMsTTzTH3DowGy-zV7Y8hoRpfZT2ZDb4Xo6xwNhnT50Sh7S_KWuMMGXU"      

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Mitsusbishi2121",
  database="mydatabase"
)


f = open('config.json')
config = json.load(f)

options = webdriver.ChromeOptions()
options.add_experimental_option('excludeSwitches', ['enable-logging'])
options.add_argument('--headless')
options.add_argument('--disable-gpu')
browser = webdriver.Chrome(ChromeDriverManager().install(), options=options)
browser.get("https://devgaming.pl")
browser.add_cookie({"name":"ips4_member_id","domain":"devgaming.pl","value":"190762"})
browser.add_cookie({"name":"ips4_browserNotificationDismiss","domain":"devgaming.pl","value":"true"})
browser.add_cookie({"name":"ips4_hasJS","domain":"devgaming.pl","value":"true"})
browser.add_cookie({"name":"ips4_ipsTimezone","domain":"devgaming.pl","value":"Europe/Warsaw"})
browser.add_cookie({"name":"ips4_forum_list_view","domain":"devgaming.pl","value":"list"})
browser.add_cookie({"name":"ips4_device_key","domain":"devgaming.pl","value":"f6c70a7fc80f17402b617e027a92055b"})
browser.add_cookie({"name":"ips4_IPSSessionFront","domain":"devgaming.pl","value":"2rnb5suac59bnd35l7g3ldl1in"})
browser.add_cookie({"name":"ips4_loggedIn","domain":"devgaming.pl","value":"1655632961"})
browser.add_cookie({"name":"ips4_login_key","domain":"devgaming.pl","value":"02089582077e0c43c29167f980ce7c40"})

def check_exists_by_xpath(xpath):
    try:
        browser.find_element(by=By.XPATH, value=xpath)
    except NoSuchElementException:
        return False
    return True

def myround(x, base=50):
    return base * round(x/base)

def word_count(str):
    counts = dict()
    words = str.split()

    for word in words:
        if word in counts:
            counts[word] += 1
        else:
            counts[word] = 1

    return counts

intents = discord.Intents.all()

client = commands.Bot(command_prefix=config["PREFIX"], intents = intents)
@client.command()
@has_permissions(manage_roles=True)
async def duty(ctx):
    mycursor = mydb.cursor()
    zysk = 0
    # Tworzenie Embedów
    MainManagementEmbed=discord.Embed(title="Zarząd główny", url="https://devgaming.pl/group/2874-220462/dashboard/", color=0xFF5733)
    SupervisorEmbed=discord.Embed(title="Supervisor", url="https://devgaming.pl/group/2874-220462/dashboard/", color=0xFF5733)
    BoulangerEmbed=discord.Embed(title="Boulanger", url="https://devgaming.pl/group/2874-220462/dashboard/", color=0xFF5733)
    CommisEmbed=discord.Embed(title="Commis", url="https://devgaming.pl/group/2874-220462/dashboard/", color=0xFF5733)
    ApprenticeEmbed=discord.Embed(title="Apprentice", url="https://devgaming.pl/group/2874-220462/dashboard/", color=0xFF5733)
    # Tworzenie Embedów /END

    # Zliczanie ofek
    tr1 = 1
    page = 1
    ofki = ""
    today1 = datetime.now() - timedelta(hours=4)
    today1 = '{:%d.%m.%Y}'.format(today1)
    for i in repeat(None, 5):
        browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=" + str(page))
        for i in repeat(None, 20):
            LogNickPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[2]"""
            LogNick = browser.find_element(by=By.XPATH, value=LogNickPath) 
            TimeOfkiPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[3]/span[2]"""
            TimeOfki = browser.find_element(by=By.XPATH, value=TimeOfkiPath) 
            TypeOfkiPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[3]/span[1]"""
            TypeOfki = browser.find_element(by=By.XPATH, value=TypeOfkiPath) 
            ZyskOfkiPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[3]/span[1]"""
            ZyskOfki = browser.find_element(by=By.XPATH, value=ZyskOfkiPath) 
            if TimeOfki.text.split()[0] == today1:
                if TypeOfki.text.split()[1] == "(podaj":
                    ofki = ofki + " " + LogNick.text
                    file_object = open(LogNick.text + ".txt", 'a')
                    file_object.write(ZyskOfki.text.split()[3][3:] + "+")
                    file_object.close()
            tr1 = tr1 + 1
        page = page + 1
        tr1 = 1
    # Zliczanie ofek /END
    
    # Zliczanie minut + dodawanie informacji do Embedów
    browser.get("https://devgaming.pl/group/2874-220462/dashboard/")
    div1 = 1
    tr1 = 1
    td1 = 1
    span1 = 1
    Done = 0
    for i in repeat(None, config["roles"]):
        for i in repeat(None, 30):
            NickNamePath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(div1) + """]/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[""" + str(td1) + """]/span[""" + str(span1) + """]"""
            MinutesPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(div1) + """]/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[2]/span[""" + str(span1) + """]"""
            if(check_exists_by_xpath(NickNamePath)):
                Nick = browser.find_element(by=By.XPATH, value=NickNamePath) 
                Min = browser.find_element(by=By.XPATH, value=MinutesPath) 
                path_to_file = Nick.text.replace(" (?)", "") + ".txt"
                path = Path(path_to_file)
                if path.is_file():
                    with open(Nick.text.replace(" (?)", "") + ".txt") as f:
                        contents1 = f.read()
                        answers1 = [eval(contents1 + "0")]
                        answers = str(answers1).replace("[", "").replace("]", "")
                        zysk =  float(answers)
                else:
                    file_object = open(Nick.text.replace(" (?)", "") + ".txt", 'a')
                    file_object.write("0" + "+")
                    file_object.close()
                    zysk = 0

                if "Role" + str(div1) in config["MainManagement"]:
                    MainManagementEmbed.add_field(name= str(Nick.text).replace(" (?)", ""), value="**M:** " + Min.text[:-4] + " **O:** " + str(ofki.count(Nick.text.replace(" (?)", ""))) + " **Z**: " + str(round(zysk * 0.9)) + "$", inline=False)
                else:
                    if config["Role" + str(div1)] == "Supervisor":
                        SupervisorEmbed.add_field(name= str(Nick.text).replace(" (?)", ""), value="**M:** " + Min.text[:-4] + " **O:** " + str(ofki.count(Nick.text.replace(" (?)", ""))) + " **Z**: " + str(round(zysk * 0.9)) + "$", inline=False)
                    if config["Role" + str(div1)] == "Boulanger":
                        BoulangerEmbed.add_field(name= str(Nick.text).replace(" (?)", ""), value="**M:** " + Min.text[:-4] + " **O:** " + str(ofki.count(Nick.text.replace(" (?)", ""))) + " **Z**: " + str(round(zysk * 0.9)) + "$", inline=False)
                    if config["Role" + str(div1)] == "Commis":
                        CommisEmbed.add_field(name= str(Nick.text).replace(" (?)", ""), value="**M:** " + Min.text[:-4] + " **O:** " + str(ofki.count(Nick.text.replace(" (?)", ""))) + " **Z**: " + str(round(zysk * 0.9)) + "$", inline=False)
                    if config["Role" + str(div1)] == "Apprentice":
                        ApprenticeEmbed.add_field(name= str(Nick.text).replace(" (?)", ""), value="**M:** " + Min.text[:-4] + " **O:** " + str(ofki.count(Nick.text.replace(" (?)", ""))) + " **Z**: " + str(round(zysk * 0.9)) + "$", inline=False)
                Tablename = datetime.now() - timedelta(hours=4)
                Tablename = '{:%d.%m.%Y}'.format(Tablename)
                if Done ==  0:
                    mycursor.execute("SHOW TABLES WHERE Tables_in_mydatabase = '" + Tablename + "'")
                    for x in mycursor:
                        mycursor.execute("DROP TABLE `" + Tablename + "`")
                    mycursor.execute("CREATE TABLE `" + Tablename + "` (`ID` INT NOT NULL AUTO_INCREMENT,`Ranga` VARCHAR(45) NULL,`Nick` VARCHAR(100) NULL,`Ofki` VARCHAR(45) NULL,`Minut` VARCHAR(45) NULL,`Zysk` VARCHAR(45) NULL,PRIMARY KEY (`ID`));")
                    Done = 1
                print("INSERT INTO `" + Tablename + "` (`Ranga`, `Nick`, `Ofki`, `Minut`, `Zysk`) VALUES ('" + config["Role" + str(div1)] + "', '" + str(Nick.text).replace(" (?)", "") + "', '" + str(ofki.count(Nick.text.replace(" (?)", ""))) + "', '" + Min.text[:-4] + "', '" + str(round(zysk * 0.9)) + "$" +"');")
                mycursor.execute("INSERT INTO `" + Tablename + "` (`Ranga`, `Nick`, `Ofki`, `Minut`, `Zysk`) VALUES ('" + config["Role" + str(div1)] + "', '" + str(Nick.text).replace(" (?)", "") + "', '" + str(ofki.count(Nick.text.replace(" (?)", ""))) + "', '" + Min.text[:-4] + "', '" + str(round(zysk * 0.9)) + "$" +"');")
                mydb.commit()
            tr1 = tr1 + 1 
        div1 = div1 + 1
        tr1 = 1
    # Zliczanie minut + dodawanie informacji do Embedów /END

    # Wysyłanie embedów
    await ctx.send(embed=MainManagementEmbed)
    await ctx.send(embed=SupervisorEmbed)
    await ctx.send(embed=BoulangerEmbed)
    await ctx.send(embed=CommisEmbed)
    await ctx.send(embed=ApprenticeEmbed)
    # Wysyłanie embedów /END

    # Usuwanie plików txt
    dir_name = "./"
    test = os.listdir(dir_name)

    for item in test:
        if item.endswith(".txt"):
            os.remove(os.path.join(dir_name, item))
    # Usuwanie plików txt /END

@client.command()
@has_permissions(manage_roles=True)
async def auto(ctx):
    mycursor = mydb.cursor()
    browser.get("https://devgaming.pl/group/2874-220462/dashboard/")
    div1 = 2
    tr1 = 1
    for i in repeat(None, config["roles"] - 1):
        for i in repeat(None, 30):
            MinPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(div1) + """]/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[2]/span[1]"""
            if(check_exists_by_xpath(MinPath)):
                Min = browser.find_element(by=By.XPATH, value=MinPath) 
                PayDay = myround(float(Min.text[:-4]) * 8.88888)
                if PayDay > 100:
                    if PayDay > 800:
                        PayDay = 800
                else:
                    PayDay = 0
                print(Min.text[:-4])
                BtnPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(div1) + """]/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[6]/a[1]"""
                search_btn = browser.find_element(by=By.XPATH, value=BtnPath) 
                search_btn.click()
                time.sleep(1)
                search_input = browser.find_element(by=By.XPATH, value="""//*[@id="form_payday"]/div/input""") 
                search_input.clear()
                search_input.send_keys(round(PayDay))
                time.sleep(1)
                search_btn = browser.find_element(by=By.XPATH, value="//button[text()='Zapisz']") 
                search_btn.click()
                time.sleep(1)
                tr1 = tr1 + 1
        div1 = div1 + 1
        tr1 = 1
    DotationPath = """//*[@id="elSettingsTabs"]/div[1]/div/span[1]/span[2]""" 
    Dotation = browser.find_element(by=By.XPATH, value=DotationPath) 
    PayDaysPath = """//*[@id="elSettingsTabs"]/div[1]/div/span[2]/span[2]"""
    PayDays = browser.find_element(by=By.XPATH, value=PayDaysPath) 
    Nadmiar = float(Dotation.text[1:][:-5]) - float(PayDays.text[1:])
    if Nadmiar > 0:
        LaylaPDPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr/td[4]"""
        LaylaPD = browser.find_element(by=By.XPATH, value=LaylaPDPath) 
        if Nadmiar + float(LaylaPD.text[1:]) >= 800:
            NPayDay = "800"
        else:
            if Nadmiar + float(LaylaPD.text[1:]) < 800:
                NPayDay = Nadmiar + float(LaylaPD.text[1:])
        BtnPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr[1]/td[6]/a[1]"""
        search_btn = browser.find_element(by=By.XPATH, value=BtnPath) 
        search_btn.click()
        time.sleep(1)
        search_input = browser.find_element(by=By.XPATH, value="""//*[@id="form_payday"]/div/input""") 
        search_input.clear()
        search_input.send_keys(NPayDay)
        time.sleep(1)
        search_btn = browser.find_element(by=By.XPATH, value="//button[text()='Zapisz']") 
        search_btn.click()
        time.sleep(1)
    DotationPath = """//*[@id="elSettingsTabs"]/div[1]/div/span[1]/span[2]""" 
    Dotation = browser.find_element(by=By.XPATH, value=DotationPath) 
    PayDaysPath = """//*[@id="elSettingsTabs"]/div[1]/div/span[2]/span[2]"""
    PayDays = browser.find_element(by=By.XPATH, value=PayDaysPath) 
    Nadmiar = float(Dotation.text[1:][:-5]) - float(PayDays.text[1:])
    if Nadmiar > 0:
        AmeliaPDPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[4]"""
        AmeliaPD = browser.find_element(by=By.XPATH, value=AmeliaPDPath) 
        if Nadmiar + float(AmeliaPD.text[1:]) >= 800:
            NPayDay = "800"
        else:
            if Nadmiar + float(AmeliaPD.text[1:]) < 800:
                NPayDay = Nadmiar + float(AmeliaPD.text[1:])
        BtnPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr[1]/td[6]/a[1]"""
        search_btn = browser.find_element(by=By.XPATH, value=BtnPath) 
        search_btn.click()
        time.sleep(1)
        search_input = browser.find_element(by=By.XPATH, value="""//*[@id="form_payday"]/div/input""") 
        search_input.clear()
        search_input.send_keys(NPayDay)
        time.sleep(1)
        search_btn = browser.find_element(by=By.XPATH, value="//button[text()='Zapisz']") 
        search_btn.click()
        time.sleep(1)
    div2 = 0
    tr2 = 1
    if Nadmiar < 0:
        Today = datetime.now() - timedelta(hours=4)
        Today = '{:%d.%m.%Y}'.format(Today)
        webhook = DiscordWebhook(url= WebhookURL , content= "**" + str(Today) + "**")
        response = webhook.execute()
    for i in repeat(None, config["roles"] - 1):
        
        for i in repeat(None, 10):
            
            if Nadmiar < 0:
                
                RoleList = [7,9,3,10,4,5,6,2]
                PayDayPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(RoleList[div2]) + """]/div/div/div/table/tbody/tr[""" + str(tr2) + """]/td[4]"""
                if(check_exists_by_xpath(PayDayPath)):
                    PayDay = browser.find_element(by=By.XPATH, value=PayDayPath) 
                    NickPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(RoleList[div2]) + """]/div/div/div/table/tbody/tr[""" + str(tr2) + """]/td[1]"""
                    Nick = browser.find_element(by=By.XPATH, value=NickPath) 
                    if float(PayDay.text[1:]) >= float(str(Nadmiar).replace("-", "")):
                        print(1)
                        print(float(str(Nadmiar).replace("-", "")))
                        print(float(PayDay.text[1:]))
                        NPayDay = float(PayDay.text[1:]) - float(str(Nadmiar).replace("-", ""))
                        Nadmiar = 0
                    else:
                        print(2)
                        if float(PayDay.text[1:]) < float(str(Nadmiar).replace("-", "")):
                            print(3)
                            Nadmiar = float(str(Nadmiar)) + float(PayDay.text[1:]) 
                            NPayDay = 0
                    if float(PayDay.text[1:]) > 0:
                        print(NPayDay)
                        print(float(PayDay.text[1:]))
                        webhook = DiscordWebhook(url= WebhookURL , content= "**" + Nick.text + ":** " + str(float(PayDay.text[1:]) - NPayDay))
                        response = webhook.execute()
                    BtnPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(RoleList[div2]) + """]/div/div/div/table/tbody/tr[""" + str(tr2) + """]/td[6]/a[1]"""
                    search_btn = browser.find_element(by=By.XPATH, value=BtnPath) 
                    search_btn.click()
                    time.sleep(1)
                    search_input = browser.find_element(by=By.XPATH, value="""//*[@id="form_payday"]/div/input""") 
                    search_input.clear()
                    search_input.send_keys(NPayDay)
                    time.sleep(1)
                    search_btn = browser.find_element(by=By.XPATH, value="//button[text()='Zapisz']") 
                    search_btn.click()
                    time.sleep(1)
                    print(Nadmiar)
            tr2 = tr2 + 1
        div2 = div2 + 1
        tr2 = 1

@client.command(pass_context=True)
async def me(ctx, args1="7623"):
    mycursor = mydb.cursor()
    if args1 == "7623":
        await ctx.send("Prawidłowe użycie komendy: .me today / .me DD-MM-YYYY / .me week")
    if args1 == "week":
        ICNick = ctx.message.author.display_name.replace(" I ", "|").replace(" | ", "|").split("|")
        NickExist = len(ICNick)
        if NickExist == 2:
            browser.get("https://devgaming.pl/group/2874-220462/dashboard/")
            if ctx.message.author.id == 483908921443221505:
                ICNick[1] = "Sakhee Maindown"
            if ctx.message.author.id == 219160512066224129:
                ICNick[1] = "Layla Carter"
            if ctx.message.author.id == 511551699895451649:
                ICNick[1] = "Michael Papaya"
            div1 = 1
            Exist = 0
            tr1 = 1
            td1 = 1
            span1 = 1
            Done = 0
            msg = await ctx.send("Pobieranie statystyk...")
            for i in repeat(None, config["roles"]):
                for i in repeat(None, 30):
                    NickNamePath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(div1) + """]/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[""" + str(td1) + """]/span[""" + str(span1) + """]"""
                    MinutesPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(div1) + """]/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[2]/span[""" + str(span1) + """]"""
                    if(check_exists_by_xpath(NickNamePath)):
                        Nick = browser.find_element(by=By.XPATH, value=NickNamePath) 
                        if Nick.text.replace(" (?)", "") == ICNick[1]:
                            Exist = 1
                            Min = browser.find_element(by=By.XPATH, value=MinutesPath) 
                            Minuty = Min.text
                            tr1 = 1
                            page = 1
                            ofki = ""
                            today1 = datetime.now() - timedelta(hours=4)
                            today1 = '{:%d.%m.%Y}'.format(today1)
                            for i in repeat(None, 5):
                                browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=" + str(page))
                                for i in repeat(None, 20):
                                    LogNickPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[2]"""
                                    LogNick = browser.find_element(by=By.XPATH, value=LogNickPath) 
                                    TimeOfkiPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[3]/span[2]"""
                                    TimeOfki = browser.find_element(by=By.XPATH, value=TimeOfkiPath) 
                                    TypeOfkiPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[3]/span[1]"""
                                    TypeOfki = browser.find_element(by=By.XPATH, value=TypeOfkiPath) 
                                    if TimeOfki.text.split()[0] == today1:
                                        if TypeOfki.text.split()[1] == "(podaj":
                                            if LogNick.text == str(ICNick[1]):
                                                ofki = ofki + " " + LogNick.text
                                    tr1 = tr1 + 1
                                page = page + 1
                                tr1 = 1
                            Oferty = str(ofki.count(str(ICNick[1])[1:]))
                            today = datetime.now()
                            idx = (today.weekday() + 1) 
                            sun = today - timedelta(idx)
                            days = str(today - sun)[:1]

                            DTS = 1
                            OfertyTyg = 0
                            MinutyTyg = 0
                            ZyskTyg = 0
                            for i in repeat(None, int(days)):
                                mycursor = mydb.cursor()
                                data = today - timedelta(days=DTS)
                                data2 = '{:%d.%m.%Y}'.format(data)
                                mycursor.execute("SELECT * FROM `" + str(data2) + "` WHERE Nick = '" + ICNick[1] + "'")

                                myresult = mycursor.fetchall()
                                for x in myresult:
                                    OfertyTyg = OfertyTyg + float(x[3])
                                    MinutyTyg = MinutyTyg + float(x[4])
                                DTS = DTS + 1
                            StatystykiMeEmbed=discord.Embed(title="Statystyki " + ICNick[0], url="https://devgaming.pl/group/2874-220462/dashboard/", color=0xFF5733)
                            StatystykiMeEmbed.add_field(name= str(ICNick[1]), value="**M:** " + str(round(float(str(Minuty)[:-4]) + float(MinutyTyg))) + " **O:** " + str(round(float(Oferty) + float(OfertyTyg))), inline=False)
                    tr1 = tr1 + 1
                div1 = div1 + 1
                tr1 = 1
            await msg.delete()
            if Exist == 1:
                await ctx.send(embed=StatystykiMeEmbed)
            else:
                await ctx.send("Nie wykryto postaci. <@501300766175133706>")
        else:
            await ctx.send("Nie wykryto nicku IC w pseudonimie.")
    if args1 == "today":
        ICNick = ctx.message.author.display_name.replace(" I ", "|").replace(" | ", "|").split("|")
        NickExist = len(ICNick)
        if NickExist == 2:
            browser.get("https://devgaming.pl/group/2874-220462/dashboard/")
            if ctx.message.author.id == 483908921443221505:
                ICNick[1] = "Sakhee Maindown"
            if ctx.message.author.id == 219160512066224129:
                ICNick[1] = "Layla Carter"
            if ctx.message.author.id == 511551699895451649:
                ICNick[1] = "Michael Papaya"
            div1 = 1
            Exist = 0
            tr1 = 1
            td1 = 1
            span1 = 1
            Done = 0
            msg = await ctx.send("Pobieranie statystyk...")
            for i in repeat(None, config["roles"]):
                for i in repeat(None, 30):
                    NickNamePath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(div1) + """]/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[""" + str(td1) + """]/span[""" + str(span1) + """]"""
                    MinutesPath = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[""" + str(div1) + """]/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[2]/span[""" + str(span1) + """]"""
                    if(check_exists_by_xpath(NickNamePath)):
                        Nick = browser.find_element(by=By.XPATH, value=NickNamePath) 
                        if Nick.text.replace(" (?)", "") == ICNick[1]:
                            Exist = 1
                            Min = browser.find_element(by=By.XPATH, value=MinutesPath) 
                            Minuty = Min.text
                            tr1 = 1
                            page = 1
                            ofki = ""
                            today1 = datetime.now() - timedelta(hours=4)
                            today1 = '{:%d.%m.%Y}'.format(today1)
                            for i in repeat(None, 5):
                                browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=" + str(page))
                                for i in repeat(None, 20):
                                    LogNickPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[2]"""
                                    LogNick = browser.find_element(by=By.XPATH, value=LogNickPath) 
                                    TimeOfkiPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[3]/span[2]"""
                                    TimeOfki = browser.find_element(by=By.XPATH, value=TimeOfkiPath) 
                                    TypeOfkiPath = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(tr1) + """]/td[3]/span[1]"""
                                    TypeOfki = browser.find_element(by=By.XPATH, value=TypeOfkiPath) 
                                    if TimeOfki.text.split()[0] == today1:
                                        if TypeOfki.text.split()[1] == "(podaj":
                                            if LogNick.text == str(ICNick[1]):
                                                ofki = ofki + " " + LogNick.text
                                    tr1 = tr1 + 1
                                page = page + 1
                                tr1 = 1
                            Oferty = str(ofki.count(str(ICNick[1])[1:]))
                            StatystykiMeEmbed=discord.Embed(title="Statystyki " + ICNick[0], url="https://devgaming.pl/group/2874-220462/dashboard/", color=0xFF5733)
                            StatystykiMeEmbed.add_field(name= str(ICNick[1]), value="**M:** " + str(Minuty) + " **O:** " + str(Oferty), inline=False)
                    tr1 = tr1 + 1
                div1 = div1 + 1
                tr1 = 1
            await msg.delete()
            if Exist == 1:
                await ctx.send(embed=StatystykiMeEmbed)
            else:
                await ctx.send("Nie wykryto postaci. <@501300766175133706>")
        else:
            await ctx.send("Nie wykryto nicku IC w pseudonimie.")
    if args1 == "today" or args1 == "week" or args1 == "7623":
        print()
    else:
        ICNick = ctx.message.author.display_name.replace(" I ", "|").replace(" | ", "|").split("|")
        NickExist = len(ICNick)
        if NickExist == 2:
            browser.get("https://devgaming.pl/group/2874-220462/dashboard/")
            if ctx.message.author.id == 483908921443221505:
                ICNick[1] = "Sakhee Maindown"
            if ctx.message.author.id == 219160512066224129:
                ICNick[1] = "Layla Carter"
            if ctx.message.author.id == 511551699895451649:
                ICNick[1] = "Michael Papaya"
            try:
                DataNow = datetime.now() - timedelta(hours=4)
                DataNow2 = DataNow.strftime("%d.%m.%Y")
                data = datetime.strptime(args1, "%d-%m-%Y").date().strftime("%d.%m.%Y")
                if data == DataNow2:
                    await ctx.send("Próbujesz pozyskać statystyki z dzisiaj, użyj komendy .me today.")
                else:
                    mycursor.execute("SHOW tables WHERE Tables_in_mydatabase = '" + str(data) + "'")
                    Exist = 0
                    for x in mycursor:
                        Exist = 1
                    if Exist == 1:
                        Exist2 = 0
                        print(ICNick[1])
                        mycursor.execute("SELECT * FROM `" + str(data) + "` WHERE Nick = '" + ICNick[1] + "'")
                        print("SELECT * FROM `" + str(data) + "` WHERE Nick = '" + ICNick[1] + "'")

                        myresult = mycursor.fetchall()
                        for x in myresult:
                            Exist2 = 1
                        if Exist2 == 1:
                            StatystykiMeEmbed=discord.Embed(title="Statystyki " + ICNick[0], url="https://devgaming.pl/group/2874-220462/dashboard/", color=0xFF5733)
                            StatystykiMeEmbed.add_field(name= str(ICNick[1]), value="**M:** " + myresult[0][4] + " **O:** " + myresult[0][3], inline=False)
                            await ctx.send(embed=StatystykiMeEmbed)
                        else:
                            await ctx.send("Nie znaleziono statystyk twojej postaci z tego dnia.")
                    else:
                        await ctx.send("Nie znaleziono statystyk z danego dnia.")
            except:
                await ctx.send("Prawidłowe użycie komendy: .me today / .me DD-MM-YYYY / .me week")

@client.event
async def on_member_join(member):
    channel = client.get_channel(846294728240267278)
    embed=discord.Embed(title="Rejestracja Baguette", url="https://devgaming.pl/topic/284772-gastronomia-baguette/", description="***Zarejestruj się, aby uzyskać dostęp do kanałów:***", color=0xFFFFFF)
    embed.set_thumbnail(url="https://i.imgur.com/UGDDkSc.png")
    embed.add_field(name="Rejestracja jako **klient**:", value=".register K", inline=True)
    embed.add_field(name="Rejestracja jako **pracownik**:", value=".register P Imię Nazwisko", inline=True)
    await channel.send(embed=embed)

@client.command(pass_context=True)
async def register(ctx, args1="7623", args2="7623", args3="7623"):
    if ctx.channel.id == 846294728240267278: 
        if args1 == "7623":
            await ctx.send("Nie wybrano typu rejestracji.")
        else:
            if args1 == "P":
                if args2 == "7623":
                    await ctx.send("Nie wpisano imienia.")
                else:
                    if args3 == "7623":
                        await ctx.send("Nie wpisano nazwiska.")
                    else:
                        browser.get("https://devgaming.pl/group/2874-220462/dashboard/")
                        xpath = "//*[contains(text(), '" + args2 + " " + args3 + "')]"
                        if check_exists_by_xpath(xpath):
                            nick = ctx.message.author.display_name + " | " + args2 + " " + args3
                            print(len(nick))
                            if len(nick) > 32:
                                NickName = 32 - len(" | " + args2 + " " + args3)
                                Nick = ctx.message.author.display_name[:NickName]  + " | " + args2 + " " + args3
                                await ctx.message.author.edit(nick=Nick)
                            else:
                                await ctx.message.author.edit(nick=nick)
                            await ctx.message.author.add_roles(discord.utils.get(ctx.message.author.guild.roles, id=847002790127730699))
                            await ctx.message.author.add_roles(discord.utils.get(ctx.message.author.guild.roles, id=846302359017619456))
                            await ctx.message.author.remove_roles(discord.utils.get(ctx.message.author.guild.roles, id=846304410635599912))
                        else:
                            await ctx.send("Nie wykryto postaci w panelu, upewnij się, że zapis nicku jest prawidłowy oraz że używasz nazwiska sprzed ślubu.")
            if args1 == "K":
                await ctx.message.author.add_roles(discord.utils.get(ctx.message.author.guild.roles, id=960832087731109888))
                await ctx.message.author.remove_roles(discord.utils.get(ctx.message.author.guild.roles, id=846304410635599912))
            if args1 == "K" or args1 == "P":
                print()
            else:
                await ctx.send("Błędny typ rejestracji")



client.run(config["TOKEN"])