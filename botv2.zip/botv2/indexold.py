from stringprep import in_table_a1
from bs4 import BeautifulSoup
import urllib.request
import requests
import re
from requests.structures import CaseInsensitiveDict
from discord_webhook import DiscordWebhook
from itertools import repeat
from matplotlib import pyplot as plt
import os
from pathlib import Path
import discord
TOKEN = "OTg3ODI4MzY0MDM3NDU1OTk0.GfhoNB.E8AAefBToldMHJYIHJoZRwwOEefxR1N_FCWqiw"
from discord.ext import commands
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
import math
import pickle
from selenium import webdriver
from zoneinfo import ZoneInfo
import time
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException 
import mysql.connector
from datetime import datetime, timedelta 
WebhookURL = "https://discord.com/api/webhooks/988556491839647885/RTgNvPTAlTXiOMsTTzTH3DowGy-zV7Y8hoRpfZT2ZDb4Xo6xwNhnT50Sh7S_KWuMMGXU"      

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Mitsusbishi2121",
  database="mydatabase"
)


client = commands.Bot(command_prefix='/')
@client.command()
async def duty(ctx):
    Tablename = datetime.now() - timedelta(hours=4)
    Tablename = '{:%d.%m.%Y}'.format(Tablename)

    mycursor = mydb.cursor()

    mycursor.execute("SHOW TABLES WHERE Tables_in_mydatabase =" + " " + "'" + Tablename + "'")
    Exist = 0

    for x in mycursor: 
        sql = "DROP TABLE" + " " + "`" + str(Tablename) + "`"
        print(sql)
        mycursor.execute(sql)
        sql = "CREATE TABLE `mydatabase`.`" + str(Tablename) + "` (`ID` INT NOT NULL AUTO_INCREMENT,`Ranga` VARCHAR(45) NULL,`Nick` VARCHAR(100) NULL,`Ofki` VARCHAR(100) NULL,`Minut` VARCHAR(100) NULL,`Zysk` VARCHAR(100) NULL,PRIMARY KEY (`ID`));"
        mycursor.execute(sql)
        Exist = 1

    if Exist == 0:
        sql = "CREATE TABLE `mydatabase`.`" + str(Tablename) + "` (`ID` INT NOT NULL AUTO_INCREMENT,`Ranga` VARCHAR(45) NULL,`Nick` VARCHAR(100) NULL,`Ofki` VARCHAR(100) NULL,`Minut` VARCHAR(100) NULL,`Zysk` VARCHAR(100) NULL,PRIMARY KEY (`ID`));"
        mycursor.execute(sql)

    dir_name = "./"
    test = os.listdir(dir_name)

    for item in test:
        if item.endswith(".txt"):
            os.remove(os.path.join(dir_name, item))
    url = "https://devgaming.pl/group/2874-220462/dashboard/"

    headers = CaseInsensitiveDict()
    headers["Cookie"] = "ips4_IPSSessionFront=sfc7fhihghkbktdkqlutgo3crg; ips4_browserNotificationDismiss=true; ips4_device_key=f6c70a7fc80f17402b617e027a92055b; ips4_forum_list_view=list; ips4_hasJS=true; ips4_ipsTimezone=Europe/Warsaw; ips4_loggedIn=1655581322; ips4_login_key=02089582077e0c43c29167f980ce7c40; ips4_member_id=190762"

    resp = requests.get(url, headers=headers)

    webpage = resp.text
    cleantext = BeautifulSoup(webpage, "lxml").text

    def joinStrings(stringList):
        list=""
        for e in stringList:
            list = list + " " + e
        return list

    Duty1 = joinStrings(cleantext.split())

    Duty12 = Duty1.replace("(?)", "")

    Duty = Duty12.replace("  ", " ")

    Ceo1 = Duty.split("CEO",1)[1]

    Role1 = Ceo1.split("Apprentice",1)[:-1] # CEO

    Apprentice1 = Duty.split("Apprentice",1)[1]

    Role2 = Apprentice1.split("Menager",1)[:-1] # Apprentice

    Menager1 = Duty.split("Menager",1)[1]

    Role3 = Menager1.split("Supervisor",1)[:-1] # Menager

    Supervisor1 = Duty.split("Supervisor",1)[1]

    Role4 = Supervisor1.split("Boulanger",1)[:-1] # Supervisor

    Boulanger1 = Duty.split("Boulanger",1)[1]

    Role5 = Boulanger1.split("Commis",1)[:-1] # Boulanger

    Commis1 = Duty.split("Commis",1)[1]

    Role6 = Commis1.split("VCEO",1)[:-1] # Commis

    Vceo1 = Duty.split("VCEO",1)[1]

    Role7 = Vceo1.split("DutyManager",1)[:-1] # VCEO

    Director1 = Duty.split("Director",1)[1]

    Role8 = Director1.split("Polityka prywatności",1)[:-1] # Director FSecretary

    # Secretary

    Duty14 = Duty.split(" ")[7:][:-3]

    print(str(Role1).split()[7:][:-1])


    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.add_argument('--headless')
    options.add_argument('--disable-gpu')
    browser = webdriver.Chrome(ChromeDriverManager().install(), options=options)
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=1")
    browser.add_cookie({"name":"ips4_member_id","domain":"devgaming.pl","value":"190762"})
    browser.add_cookie({"name":"ips4_browserNotificationDismiss","domain":"devgaming.pl","value":"true"})
    browser.add_cookie({"name":"ips4_hasJS","domain":"devgaming.pl","value":"true"})
    browser.add_cookie({"name":"ips4_ipsTimezone","domain":"devgaming.pl","value":"Europe/Warsaw"})
    browser.add_cookie({"name":"ips4_forum_list_view","domain":"devgaming.pl","value":"list"})
    browser.add_cookie({"name":"ips4_device_key","domain":"devgaming.pl","value":"f6c70a7fc80f17402b617e027a92055b"})
    browser.add_cookie({"name":"ips4_IPSSessionFront","domain":"devgaming.pl","value":"2rnb5suac59bnd35l7g3ldl1in"})
    browser.add_cookie({"name":"ips4_loggedIn","domain":"devgaming.pl","value":"1655632961"})
    browser.add_cookie({"name":"ips4_login_key","domain":"devgaming.pl","value":"02089582077e0c43c29167f980ce7c40"})
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=1")

    i1 = 1
    i2 = 1
    today1 = datetime.now() - timedelta(hours=4)
    today1 = '{:%Y, %m, %d}'.format(today1)
    open(str(today1) + ".txt", "w").close()
    for i in repeat(None, 20):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
        path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
        path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
        path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
        mytext1 = browser.find_element_by_xpath(path1)
        mytext2 = browser.find_element_by_xpath(path2)
        mytext3 = browser.find_element_by_xpath(path3)
        mytext4 = browser.find_element_by_xpath(path4)
        print(mytext1.text + " " + mytext2.text + " " + mytext3.text + " " + mytext4.text)
        Ofkadate = mytext4.text.split()
        Ofkadate1 = str(Ofkadate[0])
        Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
        today1 = datetime.now() - timedelta(hours=4)
        today = '{:%Y, %m, %d}'.format(today1)
        print(today == Dataofki)
        if today == Dataofki:
            Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
            if Zysk1.startswith("Oferta"):
                file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                file_object.write(Zysk1.split()[3][1:] + "+")
                file_object = open(str(today) + ".txt", 'a')
                file_object.write(mytext2.text + " ")
        i1 = i1 + 1
        i2 = i2 + 2
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=2")
    i1 = 1
    i2 = 1
    for i in repeat(None, 20):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
        path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
        path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
        path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
        mytext1 = browser.find_element_by_xpath(path1)
        mytext2 = browser.find_element_by_xpath(path2)
        mytext3 = browser.find_element_by_xpath(path3)
        mytext4 = browser.find_element_by_xpath(path4)
        print(mytext1.text + " " + mytext2.text + " " + mytext3.text + " " + mytext4.text)
        Ofkadate = mytext4.text.split()
        Ofkadate1 = str(Ofkadate[0])
        Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
        today1 = datetime.now() - timedelta(hours=4)
        today = '{:%Y, %m, %d}'.format(today1)
        print(today == Dataofki)
        if today == Dataofki:
            Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
            if Zysk1.startswith("Oferta"):
                file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                file_object.write(Zysk1.split()[3][1:] + "+")
                file_object = open(str(today) + ".txt", 'a')
                file_object.write(mytext2.text + " ")
        i1 = i1 + 1
        i2 = i2 + 2
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=3")
    i1 = 1
    i2 = 1
    for i in repeat(None, 20):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
        path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
        path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
        path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
        mytext1 = browser.find_element_by_xpath(path1)
        mytext2 = browser.find_element_by_xpath(path2)
        mytext3 = browser.find_element_by_xpath(path3)
        mytext4 = browser.find_element_by_xpath(path4)
        print(mytext1.text + " " + mytext2.text + " " + mytext3.text + " " + mytext4.text)
        Ofkadate = mytext4.text.split()
        Ofkadate1 = str(Ofkadate[0])
        Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
        today1 = datetime.now() - timedelta(hours=4)
        today = '{:%Y, %m, %d}'.format(today1)
        print(today == Dataofki)
        if today == Dataofki:
            Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
            if Zysk1.startswith("Oferta"):
                file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                file_object.write(Zysk1.split()[3][1:] + "+")
                file_object = open(str(today) + ".txt", 'a')
                file_object.write(mytext2.text + " ")
        i1 = i1 + 1
        i2 = i2 + 2
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=4")
    i1 = 1
    i2 = 1
    for i in repeat(None, 20):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
        path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
        path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
        path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
        mytext1 = browser.find_element_by_xpath(path1)
        mytext2 = browser.find_element_by_xpath(path2)
        mytext3 = browser.find_element_by_xpath(path3)
        mytext4 = browser.find_element_by_xpath(path4)
        print(mytext1.text + " " + mytext2.text + " " + mytext3.text + " " + mytext4.text)
        Ofkadate = mytext4.text.split()
        Ofkadate1 = str(Ofkadate[0])
        Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
        today1 = datetime.now() - timedelta(hours=4)
        today = '{:%Y, %m, %d}'.format(today1)
        print(today == Dataofki)
        if today == Dataofki:
            Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
            if Zysk1.startswith("Oferta"):
                file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                file_object.write(Zysk1.split()[3][1:] + "+")
                file_object = open(str(today) + ".txt", 'a')
                file_object.write(mytext2.text + " ")
        i1 = i1 + 1
        i2 = i2 + 2
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=5")
    i1 = 1
    i2 = 1
    for i in repeat(None, 20):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
        path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
        path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
        path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
        mytext1 = browser.find_element_by_xpath(path1)
        mytext2 = browser.find_element_by_xpath(path2)
        mytext3 = browser.find_element_by_xpath(path3)
        mytext4 = browser.find_element_by_xpath(path4)
        print(mytext1.text + " " + mytext2.text + " " + mytext3.text + " " + mytext4.text)
        Ofkadate = mytext4.text.split()
        Ofkadate1 = str(Ofkadate[0])
        Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
        today1 = datetime.now() - timedelta(hours=4)
        today = '{:%Y, %m, %d}'.format(today1)
        print(today == Dataofki)
        if today == Dataofki:
            Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
            if Zysk1.startswith("Oferta"):
                file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                file_object.write(Zysk1.split()[3][1:] + "+")
                file_object = open(str(today) + ".txt", 'a')
                file_object.write(mytext2.text + " ")
        i1 = i1 + 1
        i2 = i2 + 2
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=6")
    i1 = 1
    i2 = 1
    for i in repeat(None, 20):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
        path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
        path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
        path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
        mytext1 = browser.find_element_by_xpath(path1)
        mytext2 = browser.find_element_by_xpath(path2)
        mytext3 = browser.find_element_by_xpath(path3)
        mytext4 = browser.find_element_by_xpath(path4)
        print(mytext1.text + " " + mytext2.text + " " + mytext3.text + " " + mytext4.text)
        Ofkadate = mytext4.text.split()
        Ofkadate1 = str(Ofkadate[0])
        Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
        today1 = datetime.now() - timedelta(hours=4)
        today = '{:%Y, %m, %d}'.format(today1)
        print(today == Dataofki)
        if today == Dataofki:
            Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
            if Zysk1.startswith("Oferta"):
                file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                file_object.write(Zysk1.split()[3][1:] + "+")
                file_object = open(str(today) + ".txt", 'a')
                file_object.write(mytext2.text + " ")
        i1 = i1 + 1
        i2 = i2 + 2


    i3 = 0
    i4 = 1
    i5 = 2
    Roles = len(str(Role1).split()[7:][:-1])
    Rolesnr = Roles // 9
    embed=discord.Embed(title="Zarząd główny", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
    for i in repeat(None, Rolesnr):
        with open(str(today) + ".txt") as f:
            contents = f.read()
            count = contents.count(str(Role1).split()[7:][:-1][i3] + " " + str(Role1).split()[7:][:-1][i4])
            file_object = open(str(Role1).split()[7:][:-1][i3] + " " + str(Role1).split()[7:][:-1][i4] + str(today) + ".txt", 'a')
        
        with open(str(Role1).split()[7:][:-1][i3] + " " + str(Role1).split()[7:][:-1][i4] + str(today) + ".txt") as f:
            contents1 = f.read()

            answers1 = [eval(contents1 + "0")]
            answers = str(answers1).replace("[", "").replace("]", "")
            zysk = float(answers)
            print(answers)

        embed.add_field(name= str(Role1).split()[7:][:-1][i3] + " " + str(Role1).split()[7:][:-1][i4], value="**MIN:**" + " " + str(Role1).split()[7:][:-1][i5] + " " + "**O:**" + " " + str(count) + " " + "**Z:**" + " " + str(round(zysk * 0.9)) + "$", inline=False)
        print(str(count))
        sql = "INSERT INTO `mydatabase`.`" + str(Tablename) + "` (`Ranga`, `Nick`, `Minut`, `Ofki`,`Zysk`) VALUES ('CEO', '" + str(Role1).split()[7:][:-1][i3] + " " + str(Role1).split()[7:][:-1][i4] + "', '" + str(Role1).split()[7:][:-1][i5] + "', '" + str(count) + "', '" + str(round(zysk * 0.9)) + "$" + "');"
        mycursor.execute(sql)

        mydb.commit()
        i3 = i3 + 9
        i4 = i4 + 9
        i5 = i5 + 9
    i3 = 0
    i4 = 1
    i5 = 2
    Roles = len(str(Role7).split()[7:][:-1])
    Rolesnr = Roles // 9
    for i in repeat(None, Rolesnr):
        with open(str(today) + ".txt") as f:
            contents = f.read()
            count = contents.count(str(Role7).split()[7:][:-1][i3] + " " + str(Role7).split()[7:][:-1][i4])
            file_object = open(str(Role7).split()[7:][:-1][i3] + " " + str(Role7).split()[7:][:-1][i4] + str(today) + ".txt", 'a')

        with open(str(Role7).split()[7:][:-1][i3] + " " + str(Role7).split()[7:][:-1][i4] + str(today) + ".txt") as f:
            contents1 = f.read()

            answers1 = [eval(contents1 + "0")]
            answers = str(answers1).replace("[", "").replace("]", "")
            zysk = float(answers)
            print(answers)
               
        embed.add_field(name= str(Role7).split()[7:][:-1][i3] + " " + str(Role7).split()[7:][:-1][i4], value="**MIN:**" + " " + str(Role7).split()[7:][:-1][i5] + " " + "**O:**" + " " + str(count) + " " + "**Z:**" + " " + str(round(zysk * 0.9)) + "$", inline=False)
        sql = "INSERT INTO `mydatabase`.`" + str(Tablename) + "` (`Ranga`, `Nick`, `Minut`, `Ofki`,`Zysk`) VALUES ('VCEO', '" + str(Role7).split()[7:][:-1][i3] + " " + str(Role7).split()[7:][:-1][i4] + "', '" + str(Role7).split()[7:][:-1][i5] + "', '" + str(count) + "', '" + str(round(zysk * 0.9)) + "$" + "');"
        mycursor.execute(sql)

        mydb.commit()
        i3 = i3 + 9
        i4 = i4 + 9
        i5 = i5 + 9
    i3 = 0
    i4 = 1
    i5 = 2
    Roles = len(str(Role8).split()[7:][:-1])
    Rolesnr = Roles // 9
    for i in repeat(None, Rolesnr):
        with open(str(today) + ".txt") as f:
            contents = f.read()
            count = contents.count(str(Role8).split()[7:][:-1][i3] + " " + str(Role8).split()[7:][:-1][i4])
            file_object = open(str(Role8).split()[7:][:-1][i3] + " " + str(Role8).split()[7:][:-1][i4] + str(today) + ".txt", 'a')

        with open(str(Role8).split()[7:][:-1][i3] + " " + str(Role8).split()[7:][:-1][i4] + str(today) + ".txt") as f:
            contents1 = f.read()

            answers1 = [eval(contents1 + "0")]
            answers = str(answers1).replace("[", "").replace("]", "")
            zysk = float(answers)
            print(answers)
        
        
        embed.add_field(name= str(Role8).split()[7:][:-1][i3] + " " + str(Role8).split()[7:][:-1][i4], value="**MIN:**" + " " + str(Role8).split()[7:][:-1][i5] + " " + "**O:**" + " " + str(count) + " " + "**Z:**" + " " + str(round(zysk * 0.9)) + "$", inline=False)
        sql = "INSERT INTO `mydatabase`.`" + str(Tablename) + "` (`Ranga`, `Nick`, `Minut`, `Ofki`,`Zysk`) VALUES ('Director', '" + str(Role8).split()[7:][:-1][i3] + " " + str(Role8).split()[7:][:-1][i4] + "', '" + str(Role8).split()[7:][:-1][i5] + "', '" + str(count) + "', '" + str(round(zysk * 0.9)) + "$" + "');"
        mycursor.execute(sql)

        mydb.commit()
        i3 = i3 + 9
        i4 = i4 + 9
        i5 = i5 + 9
    i3 = 0
    i4 = 1
    i5 = 2
    Roles = len(str(Role3).split()[7:][:-1])
    Rolesnr = Roles // 9
    for i in repeat(None, Rolesnr):
        with open(str(today) + ".txt") as f:
            contents = f.read()
            count = contents.count(str(Role3).split()[7:][:-1][i3] + " " + str(Role3).split()[7:][:-1][i4])
            file_object = open(str(Role3).split()[7:][:-1][i3] + " " + str(Role3).split()[7:][:-1][i4] + str(today) + ".txt", 'a')

        with open(str(Role3).split()[7:][:-1][i3] + " " + str(Role3).split()[7:][:-1][i4] + str(today) + ".txt") as f:
            contents1 = f.read()

            answers1 = [eval(contents1 + "0")]
            answers = str(answers1).replace("[", "").replace("]", "")
            zysk = float(answers)
            print(answers)
        
        
        embed.add_field(name= str(Role3).split()[7:][:-1][i3] + " " + str(Role3).split()[7:][:-1][i4], value="**MIN:**" + " " + str(Role3).split()[7:][:-1][i5] + " " + "**O:**" + " " + str(count) + " " + "**Z:**" + " " + str(round(zysk * 0.9)) + "$", inline=False)
        sql = "INSERT INTO `mydatabase`.`" + str(Tablename) + "` (`Ranga`, `Nick`, `Minut`, `Ofki`,`Zysk`) VALUES ('Menager', '" + str(Role3).split()[7:][:-1][i3] + " " + str(Role3).split()[7:][:-1][i4] + "', '" + str(Role3).split()[7:][:-1][i5] + "', '" + str(count) + "', '" + str(round(zysk * 0.9)) + "$" + "');"
        mycursor.execute(sql)

        mydb.commit()
        i3 = i3 + 9
        i4 = i4 + 9
        i5 = i5 + 9
    await ctx.send(embed=embed)
    i3 = 0
    i4 = 1
    i5 = 2
    Roles = len(str(Role4).split()[7:][:-1])
    Rolesnr = Roles // 9

    # Secretary

    embed=discord.Embed(title="Supervisor", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
    for i in repeat(None, Rolesnr):
        with open(str(today) + ".txt") as f:
            contents = f.read()
            count = contents.count(str(Role4).split()[7:][:-1][i3] + " " + str(Role4).split()[7:][:-1][i4])
            file_object = open(str(Role4).split()[7:][:-1][i3] + " " + str(Role4).split()[7:][:-1][i4] + str(today) + ".txt", 'a')

        with open(str(Role4).split()[7:][:-1][i3] + " " + str(Role4).split()[7:][:-1][i4] + str(today) + ".txt") as f:
            contents1 = f.read()

            answers1 = [eval(contents1 + "0")]
            answers = str(answers1).replace("[", "").replace("]", "")
            zysk = float(answers)
            print(answers)
        
        
        embed.add_field(name= str(Role4).split()[7:][:-1][i3] + " " + str(Role4).split()[7:][:-1][i4], value="**MIN:**" + " " + str(Role4).split()[7:][:-1][i5] + " " + "**O:**" + " " + str(count) + " " + "**Z:**" + " " + str(round(zysk * 0.9)) + "$", inline=False)
        sql = "INSERT INTO `mydatabase`.`" + str(Tablename) + "` (`Ranga`, `Nick`, `Minut`, `Ofki`,`Zysk`) VALUES ('Supervisor', '" + str(Role4).split()[7:][:-1][i3] + " " + str(Role4).split()[7:][:-1][i4] + "', '" + str(Role4).split()[7:][:-1][i5] + "', '" + str(count) + "', '" + str(round(zysk * 0.9)) + "$" + "');"
        mycursor.execute(sql)

        mydb.commit()
        i3 = i3 + 9
        i4 = i4 + 9
        i5 = i5 + 9
    await ctx.send(embed=embed)
    i3 = 0
    i4 = 1
    i5 = 2
    Roles = len(str(Role5).split()[7:][:-1])
    Rolesnr = Roles // 9
    embed=discord.Embed(title="Boulanger", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
    for i in repeat(None, Rolesnr):
        with open(str(today) + ".txt") as f:
            contents = f.read()
            count = contents.count(str(Role5).split()[7:][:-1][i3] + " " + str(Role5).split()[7:][:-1][i4])
            file_object = open(str(Role5).split()[7:][:-1][i3] + " " + str(Role5).split()[7:][:-1][i4] + str(today) + ".txt", 'a')

        with open(str(Role5).split()[7:][:-1][i3] + " " + str(Role5).split()[7:][:-1][i4] + str(today) + ".txt") as f:
            contents1 = f.read()

            answers1 = [eval(contents1 + "0")]
            answers = str(answers1).replace("[", "").replace("]", "")
            zysk = float(answers)
            print(answers)     
        
        
        
        embed.add_field(name= str(Role5).split()[7:][:-1][i3] + " " + str(Role5).split()[7:][:-1][i4], value="**MIN:**" + " " + str(Role5).split()[7:][:-1][i5] + " " + "**O:**" + " " + str(count) + " " + "**Z:**" + " " + str(round(zysk * 0.9)) + "$", inline=False)
        sql = "INSERT INTO `mydatabase`.`" + str(Tablename) + "` (`Ranga`, `Nick`, `Minut`, `Ofki`,`Zysk`) VALUES ('Boulanger', '" + str(Role5).split()[7:][:-1][i3] + " " + str(Role5).split()[7:][:-1][i4] + "', '" + str(Role5).split()[7:][:-1][i5] + "', '" + str(count) + "', '" + str(round(zysk * 0.9)) + "$" + "');"
        mycursor.execute(sql)

        mydb.commit()
        i3 = i3 + 9
        i4 = i4 + 9
        i5 = i5 + 9
    await ctx.send(embed=embed)
    i3 = 0
    i4 = 1
    i5 = 2
    Roles = len(str(Role6).split()[7:][:-1])
    Rolesnr = Roles // 9
    embed=discord.Embed(title="Commis", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
    for i in repeat(None, Rolesnr):
        with open(str(today) + ".txt") as f:
            contents = f.read()
            count = contents.count(str(Role6).split()[7:][:-1][i3] + " " + str(Role6).split()[7:][:-1][i4])
            file_object = open(str(Role6).split()[7:][:-1][i3] + " " + str(Role6).split()[7:][:-1][i4] + str(today) + ".txt", 'a')

        with open(str(Role6).split()[7:][:-1][i3] + " " + str(Role6).split()[7:][:-1][i4] + str(today) + ".txt") as f:
            contents1 = f.read()

            answers1 = [eval(contents1 + "0")]
            answers = str(answers1).replace("[", "").replace("]", "")
            zysk = float(answers)
            print(answers)     
        

        embed.add_field(name= str(Role6).split()[7:][:-1][i3] + " " + str(Role6).split()[7:][:-1][i4], value="**MIN:**" + " " + str(Role6).split()[7:][:-1][i5] + " " + "**O:**" + " " + str(count) + " " + "**Z:**" + " " + str(round(zysk * 0.9)) + "$", inline=False)
        sql = "INSERT INTO `mydatabase`.`" + str(Tablename) + "` (`Ranga`, `Nick`, `Minut`, `Ofki`,`Zysk`) VALUES ('Commis', '" + str(Role6).split()[7:][:-1][i3] + " " + str(Role6).split()[7:][:-1][i4] + "', '" + str(Role6).split()[7:][:-1][i5] + "', '" + str(count) + "', '" + str(round(zysk * 0.9)) + "$" + "');"
        mycursor.execute(sql)

        mydb.commit()
        i3 = i3 + 9
        i4 = i4 + 9
        i5 = i5 + 9
    await ctx.send(embed=embed)
    i3 = 0
    i4 = 1
    i5 = 2
    Roles = len(str(Role2).split()[7:][:-1])
    Rolesnr = Roles // 9
    embed=discord.Embed(title="Apprentice", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
    for i in repeat(None, Rolesnr):
        with open(str(today) + ".txt") as f:
            contents = f.read()
            count = contents.count(str(Role2).split()[7:][:-1][i3] + " " + str(Role2).split()[7:][:-1][i4])
            file_object = open(str(Role2).split()[7:][:-1][i3] + " " + str(Role2).split()[7:][:-1][i4] + str(today) + ".txt", 'a')

        with open(str(Role2).split()[7:][:-1][i3] + " " + str(Role2).split()[7:][:-1][i4] + str(today) + ".txt") as f:
            contents1 = f.read()

            answers1 = [eval(contents1 + "0")]
            answers = str(answers1).replace("[", "").replace("]", "")
            zysk = float(answers)
            print(answers)     
        
        
        
        
        embed.add_field(name= str(Role2).split()[7:][:-1][i3] + " " + str(Role2).split()[7:][:-1][i4], value="**MIN:**" + " " + str(Role2).split()[7:][:-1][i5] + " " + "**O:**" + " " + str(count) + " " + "**Z:**" + " " + str(round(zysk * 0.9)) + "$", inline=False)
        sql = "INSERT INTO `mydatabase`.`" + str(Tablename) + "` (`Ranga`, `Nick`, `Minut`, `Ofki`,`Zysk`) VALUES ('Apprentice', '" + str(Role2).split()[7:][:-1][i3] + " " + str(Role2).split()[7:][:-1][i4] + "', '" + str(Role2).split()[7:][:-1][i5] + "', '" + str(count) + "', '" + str(round(zysk * 0.9)) + "$" + "');"
        mycursor.execute(sql)

        mydb.commit()
        i3 = i3 + 9
        i4 = i4 + 9
        i5 = i5 + 9
    await ctx.send(embed=embed)
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.add_argument('--headless')
    options.add_argument('--disable-gpu')
    browser = webdriver.Chrome(ChromeDriverManager().install(), options=options)
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=1")
    browser.add_cookie({"name":"ips4_member_id","domain":"devgaming.pl","value":"190762"})
    browser.add_cookie({"name":"ips4_browserNotificationDismiss","domain":"devgaming.pl","value":"true"})
    browser.add_cookie({"name":"ips4_hasJS","domain":"devgaming.pl","value":"true"})
    browser.add_cookie({"name":"ips4_ipsTimezone","domain":"devgaming.pl","value":"Europe/Warsaw"})
    browser.add_cookie({"name":"ips4_forum_list_view","domain":"devgaming.pl","value":"list"})
    browser.add_cookie({"name":"ips4_device_key","domain":"devgaming.pl","value":"f6c70a7fc80f17402b617e027a92055b"})
    browser.add_cookie({"name":"ips4_IPSSessionFront","domain":"devgaming.pl","value":"2rnb5suac59bnd35l7g3ldl1in"})
    browser.add_cookie({"name":"ips4_loggedIn","domain":"devgaming.pl","value":"1655632961"})
    browser.add_cookie({"name":"ips4_login_key","domain":"devgaming.pl","value":"02089582077e0c43c29167f980ce7c40"})
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=1")


    i1 = 1
    i2 = 1
    hour = 15
    pageI = 1
    today1 = datetime.now() - timedelta(hours=4)
    today1 = '{:%Y, %m, %d}'.format(today1)
    open(str(today1) + ".txt", "w").close()
    for i in repeat(None, 10):
        open(str(today1) + " " + str(hour) + ".txt", "w").close()
        for i in repeat(None, 20):
            pageI = pageI + 1
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
            path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
            path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
            path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
            mytext1 = browser.find_element_by_xpath(path1)
            mytext2 = browser.find_element_by_xpath(path2)
            mytext3 = browser.find_element_by_xpath(path3)
            mytext4 = browser.find_element_by_xpath(path4)
            Ofkadate = mytext4.text.split()
            Ofkadate1 = str(Ofkadate[0])
            Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
            today = str(today1) + " " + str(hour)
            Dataofki = Dataofki + " " + Ofkadate[1][:-3]
            if today == Dataofki:
                Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
                if Zysk1.startswith("Oferta"):
                    file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                    file_object.write(Zysk1.split()[3][1:] + "+")
                    file_object = open(str(today) + ".txt", 'a')
                    file_object.write(mytext2.text + " ")
            i1 = i1 + 1
            i2 = i2 + 2
        hour = hour + 1 
        i1 = 1
        i2 = 1

    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=2")


    i1 = 1
    i2 = 1
    hour = 15
    pageI = 1
    today1 = datetime.now() - timedelta(hours=4)
    today1 = '{:%Y, %m, %d}'.format(today1)
    open(str(today1) + ".txt", "w").close()
    for i in repeat(None, 10):
        for i in repeat(None, 20):
            pageI = pageI + 1
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
            path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
            path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
            path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
            mytext1 = browser.find_element_by_xpath(path1)
            mytext2 = browser.find_element_by_xpath(path2)
            mytext3 = browser.find_element_by_xpath(path3)
            mytext4 = browser.find_element_by_xpath(path4)
            Ofkadate = mytext4.text.split()
            Ofkadate1 = str(Ofkadate[0])
            Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
            today = str(today1) + " " + str(hour)
            Dataofki = Dataofki + " " + Ofkadate[1][:-3]
            if today == Dataofki:
                Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
                if Zysk1.startswith("Oferta"):
                    file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                    file_object.write(Zysk1.split()[3][1:] + "+")
                    file_object = open(str(today) + ".txt", 'a')
                    file_object.write(mytext2.text + " ")
            i1 = i1 + 1
            i2 = i2 + 2
        hour = hour + 1 
        i1 = 1
        i2 = 1

    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=3")

    i1 = 1
    i2 = 1
    hour = 15
    pageI = 1
    today1 = datetime.now() - timedelta(hours=4)
    today1 = '{:%Y, %m, %d}'.format(today1)
    open(str(today1) + ".txt", "w").close()
    for i in repeat(None, 10):
        for i in repeat(None, 20):
            pageI = pageI + 1
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
            path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
            path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
            path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
            mytext1 = browser.find_element_by_xpath(path1)
            mytext2 = browser.find_element_by_xpath(path2)
            mytext3 = browser.find_element_by_xpath(path3)
            mytext4 = browser.find_element_by_xpath(path4)
            Ofkadate = mytext4.text.split()
            Ofkadate1 = str(Ofkadate[0])
            Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
            today = str(today1) + " " + str(hour)
            Dataofki = Dataofki + " " + Ofkadate[1][:-3]
            if today == Dataofki:
                Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
                if Zysk1.startswith("Oferta"):
                    file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                    file_object.write(Zysk1.split()[3][1:] + "+")
                    file_object = open(str(today) + ".txt", 'a')
                    file_object.write(mytext2.text + " ")
            i1 = i1 + 1
            i2 = i2 + 2
        hour = hour + 1 
        i1 = 1
        i2 = 1

    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=4")

    i1 = 1
    i2 = 1
    hour = 15
    pageI = 1
    today1 = datetime.now() - timedelta(hours=4)
    today1 = '{:%Y, %m, %d}'.format(today1)
    open(str(today1) + ".txt", "w").close()
    for i in repeat(None, 10):
        for i in repeat(None, 20):
            pageI = pageI + 1
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
            path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
            path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
            path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
            mytext1 = browser.find_element_by_xpath(path1)
            mytext2 = browser.find_element_by_xpath(path2)
            mytext3 = browser.find_element_by_xpath(path3)
            mytext4 = browser.find_element_by_xpath(path4)
            Ofkadate = mytext4.text.split()
            Ofkadate1 = str(Ofkadate[0])
            Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
            today = str(today1) + " " + str(hour)
            Dataofki = Dataofki + " " + Ofkadate[1][:-3]
            if today == Dataofki:
                Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
                if Zysk1.startswith("Oferta"):
                    file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                    file_object.write(Zysk1.split()[3][1:] + "+")
                    file_object = open(str(today) + ".txt", 'a')
                    file_object.write(mytext2.text + " ")
            i1 = i1 + 1
            i2 = i2 + 2
        hour = hour + 1 
        i1 = 1
        i2 = 1

    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=5")

    i1 = 1
    i2 = 1
    hour = 15
    pageI = 1
    today1 = datetime.now() - timedelta(hours=4)
    today1 = '{:%Y, %m, %d}'.format(today1)
    open(str(today1) + ".txt", "w").close()
    for i in repeat(None, 10):
        for i in repeat(None, 20):
            pageI = pageI + 1
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
            path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
            path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
            path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
            mytext1 = browser.find_element_by_xpath(path1)
            mytext2 = browser.find_element_by_xpath(path2)
            mytext3 = browser.find_element_by_xpath(path3)
            mytext4 = browser.find_element_by_xpath(path4)
            Ofkadate = mytext4.text.split()
            Ofkadate1 = str(Ofkadate[0])
            Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
            today = str(today1) + " " + str(hour)
            Dataofki = Dataofki + " " + Ofkadate[1][:-3]
            if today == Dataofki:
                Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
                if Zysk1.startswith("Oferta"):
                    file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                    file_object.write(Zysk1.split()[3][1:] + "+")
                    file_object = open(str(today) + ".txt", 'a')
                    file_object.write(mytext2.text + " ")
            i1 = i1 + 1
            i2 = i2 + 2
        hour = hour + 1 
        i1 = 1
        i2 = 1

    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=6")

    i1 = 1
    i2 = 1
    hour = 15
    pageI = 1
    today1 = datetime.now() - timedelta(hours=4)
    today1 = '{:%Y, %m, %d}'.format(today1)
    open(str(today1) + ".txt", "w").close()
    for i in repeat(None, 10):
        for i in repeat(None, 20):
            pageI = pageI + 1
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
            path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
            path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
            path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
            mytext1 = browser.find_element_by_xpath(path1)
            mytext2 = browser.find_element_by_xpath(path2)
            mytext3 = browser.find_element_by_xpath(path3)
            mytext4 = browser.find_element_by_xpath(path4)
            Ofkadate = mytext4.text.split()
            Ofkadate1 = str(Ofkadate[0])
            Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
            today = str(today1) + " " + str(hour)
            Dataofki = Dataofki + " " + Ofkadate[1][:-3]
            if today == Dataofki:
                Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
                if Zysk1.startswith("Oferta"):
                    file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                    file_object.write(Zysk1.split()[3][1:] + "+")
                    file_object = open(str(today) + ".txt", 'a')
                    file_object.write(mytext2.text + " ")
            i1 = i1 + 1
            i2 = i2 + 2
        hour = hour + 1 
        i1 = 1
        i2 = 1

    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=7")

    i1 = 1
    i2 = 1
    hour = 15
    pageI = 1
    today1 = datetime.now() - timedelta(hours=4)
    today1 = '{:%Y, %m, %d}'.format(today1)
    for i in repeat(None, 10):
        for i in repeat(None, 20):
            pageI = pageI + 1
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[1]"""
            path2 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[2]"""
            path3 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[1]"""
            path4 = """//*[@id="ipsTabs_elSettingsTabs_setting_logs_panel"]/div[2]/div/div/div/div/table/tbody/tr[""" + str(i1) + """]/td[3]/span[2]"""
            mytext1 = browser.find_element_by_xpath(path1)
            mytext2 = browser.find_element_by_xpath(path2)
            mytext3 = browser.find_element_by_xpath(path3)
            mytext4 = browser.find_element_by_xpath(path4)
            Ofkadate = mytext4.text.split()
            Ofkadate1 = str(Ofkadate[0])
            Dataofki = datetime.strptime(Ofkadate1, "%d.%m.%Y").strftime("%Y, %m, %d")
            today = str(today1) + " " + str(hour)
            Dataofki = Dataofki + " " + Ofkadate[1][:-3]
            if today == Dataofki:
                Zysk1 = mytext3.text.replace("1)","").replace("2)","").replace("3)","").replace("4)","").replace("5)","").replace("6)","").replace("7)","").replace("8)","").replace("9)","").replace("10)","")
                if Zysk1.startswith("Oferta"):
                    file_object = open(str(mytext2.text)+str(today) + ".txt", 'a')
                    file_object.write(Zysk1.split()[3][1:] + "+")
                    file_object = open(str(today) + ".txt", 'a')
                    file_object.write(mytext2.text + " ")
            i1 = i1 + 1
            i2 = i2 + 2

        my_file = Path(str(today) + ".txt")
        if my_file.is_file():
            file = open(str(today) + ".txt", 'r')
            read_data = file.read()
            per_word = read_data.split()
            print(len(per_word))
            ofkiliczba = len(per_word) // 2
            mycursor = mydb.cursor()
            mycursor.execute("INSERT INTO `mydatabase`.`wykresy` (`Data`, `Godzina`, `Ofki`) VALUES ('" + str(today) + "', '" + str(hour) + "', '" + str(ofkiliczba) + "');")
            mydb.commit()
        hour = hour + 1 
        i1 = 1
        i2 = 1

@client.command()
async def auto(ctx):

    url = "https://devgaming.pl/group/2874-220462/dashboard/"

    headers = CaseInsensitiveDict()
    headers["Cookie"] = "ips4_IPSSessionFront=sfc7fhihghkbktdkqlutgo3crg; ips4_browserNotificationDismiss=true; ips4_device_key=f6c70a7fc80f17402b617e027a92055b; ips4_forum_list_view=list; ips4_hasJS=true; ips4_ipsTimezone=Europe/Warsaw; ips4_loggedIn=1655581322; ips4_login_key=02089582077e0c43c29167f980ce7c40; ips4_member_id=190762"

    resp = requests.get(url, headers=headers)

    webpage = resp.text
    cleantext = BeautifulSoup(webpage, "lxml").text

    def joinStrings(stringList):
        list=""
        for e in stringList:
            list = list + " " + e
        return list

    Duty1 = joinStrings(cleantext.split())

    Duty12 = Duty1.replace("(?)", "")

    Duty = Duty12.replace("  ", " ")

    Ceo1 = Duty.split("CEO",1)[1]

    Role1 = Ceo1.split("Apprentice",1)[:-1] # CEO

    Apprentice1 = Duty.split("Apprentice",1)[1]

    Role2 = Apprentice1.split("Menager",1)[:-1] # Apprentice

    Menager1 = Duty.split("Menager",1)[1]

    Role3 = Menager1.split("Supervisor",1)[:-1] # Menager

    Supervisor1 = Duty.split("Supervisor",1)[1]

    Role4 = Supervisor1.split("Boulanger",1)[:-1] # Supervisor

    Boulanger1 = Duty.split("Boulanger",1)[1]

    Role5 = Boulanger1.split("Commis",1)[:-1] # Boulanger

    Commis1 = Duty.split("Commis",1)[1]

    Role6 = Commis1.split("VCEO",1)[:-1] # Commis

    Vceo1 = Duty.split("VCEO",1)[1]

    Role7 = Vceo1.split("DutyManager",1)[:-1] # VCEO

    Director1 = Duty.split("Director",1)[1]

    Role8 = Director1.split("Polityka prywatności",1)[:-1] # Director FSecretary

    # Secretary
    

    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    #options.add_argument('--headless')
    #options.add_argument('--disable-gpu')
    browser = webdriver.Chrome(ChromeDriverManager().install(), options=options)
    browser.implicitly_wait(2)
    browser.get("https://devgaming.pl/group/2874-220462/logs/?listPage=1")
    browser.add_cookie({"name":"ips4_member_id","domain":"devgaming.pl","value":"190762"})
    browser.add_cookie({"name":"ips4_browserNotificationDismiss","domain":"devgaming.pl","value":"true"})
    browser.add_cookie({"name":"ips4_hasJS","domain":"devgaming.pl","value":"true"})
    browser.add_cookie({"name":"ips4_ipsTimezone","domain":"devgaming.pl","value":"Europe/Warsaw"})
    browser.add_cookie({"name":"ips4_forum_list_view","domain":"devgaming.pl","value":"list"})
    browser.add_cookie({"name":"ips4_device_key","domain":"devgaming.pl","value":"f6c70a7fc80f17402b617e027a92055b"})
    browser.add_cookie({"name":"ips4_IPSSessionFront","domain":"devgaming.pl","value":"2rnb5suac59bnd35l7g3ldl1in"})
    browser.add_cookie({"name":"ips4_loggedIn","domain":"devgaming.pl","value":"1655632961"})
    browser.add_cookie({"name":"ips4_login_key","domain":"devgaming.pl","value":"02089582077e0c43c29167f980ce7c40"})
    browser.get("https://devgaming.pl/group/2874-220462/dashboard/")

    def myround(x, base=50):
        return base * round(x/base)


    Roles = len(str(Role2).split()[7:][:-1])
    Rolesnr = Roles // 9

    MinI = 1

    for i in repeat(None, Rolesnr):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[2]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[2]/span[1]"""
        mytext1 = browser.find_element_by_xpath(path1)
        print(mytext1.text)

        PayDay = float(mytext1.text[:-4]) * 8.888888
        if PayDay > 800:
            PayDay = 800

        PDi1 = 2 # Numer diva/rola - dla testów
        PDi2 = 2 # Numer użytkownika w divie - dla testów

        if float(PayDay) > 150:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[2]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys(myround(PayDay))
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        else:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[2]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys("0")
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        MinI = MinI + 1


    Roles = len(str(Role3).split()[7:][:-1])
    Rolesnr = Roles // 9

    MinI = 1

    for i in repeat(None, Rolesnr):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[3]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[2]/span[1]"""
        mytext1 = browser.find_element_by_xpath(path1)
        print(mytext1.text)

        PayDay = float(mytext1.text[:-4]) * 8.888888
        if PayDay > 800:
            PayDay = 800

        PDi1 = 2 # Numer diva/rola - dla testów
        PDi2 = 2 # Numer użytkownika w divie - dla testów

        if float(PayDay) > 150:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[3]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys(myround(PayDay))
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        else:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[3]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys("0")
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        MinI = MinI + 1


    Roles = len(str(Role4).split()[7:][:-1])
    Rolesnr = Roles // 9

    MinI = 1

    for i in repeat(None, Rolesnr):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[4]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[2]/span[1]"""
        mytext1 = browser.find_element_by_xpath(path1)
        print(mytext1.text)

        PayDay = float(mytext1.text[:-4]) * 8.888888
        if PayDay > 800:
            PayDay = 800

        PDi1 = 2 # Numer diva/rola - dla testów
        PDi2 = 2 # Numer użytkownika w divie - dla testów

        if float(PayDay) > 150:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[4]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys(myround(PayDay))
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        else:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[4]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys("0")
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        MinI = MinI + 1


    Roles = len(str(Role5).split()[7:][:-1])
    Rolesnr = Roles // 9

    MinI = 1

    for i in repeat(None, Rolesnr):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[5]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[2]/span[1]"""
        mytext1 = browser.find_element_by_xpath(path1)
        print(mytext1.text)

        PayDay = float(mytext1.text[:-4]) * 8.888888
        if PayDay > 800:
            PayDay = 800

        PDi1 = 2 # Numer diva/rola - dla testów
        PDi2 = 2 # Numer użytkownika w divie - dla testów

        if float(PayDay) > 150:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[5]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys(myround(PayDay))
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        else:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[5]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys("0")
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        MinI = MinI + 1


    Roles = len(str(Role6).split()[7:][:-1])
    Rolesnr = Roles // 9

    MinI = 1

    for i in repeat(None, Rolesnr):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[6]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[2]/span[1]"""
        mytext1 = browser.find_element_by_xpath(path1)
        print(mytext1.text)

        PayDay = float(mytext1.text[:-4]) * 8.888888
        if PayDay > 800:
            PayDay = 800

        PDi1 = 2 # Numer diva/rola - dla testów
        PDi2 = 2 # Numer użytkownika w divie - dla testów

        if float(PayDay) > 150:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[6]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys(myround(PayDay))
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        else:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[6]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys("0")
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        MinI = MinI + 1
        
        

    Roles = len(str(Role7).split()[7:][:-1])
    Rolesnr = Roles // 9

    MinI = 1

    for i in repeat(None, Rolesnr):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[2]/span[1]"""
        mytext1 = browser.find_element_by_xpath(path1)
        print(mytext1.text)

        PayDay = float(mytext1.text[:-4]) * 8.888888
        if PayDay > 800:
            PayDay = 800

        PDi1 = 2 # Numer diva/rola - dla testów
        PDi2 = 2 # Numer użytkownika w divie - dla testów

        if float(PayDay) > 150:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys(myround(PayDay))
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        else:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys("0")
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        MinI = MinI + 1


    Roles = len(str(Role8).split()[7:][:-1])
    Rolesnr = Roles // 9

    MinI = 1

    for i in repeat(None, Rolesnr):
        path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[2]/span[1]"""
        mytext1 = browser.find_element_by_xpath(path1)
        print(mytext1.text)

        PayDay = float(mytext1.text[:-4]) * 8.888888
        if PayDay > 800:
            PayDay = 800

        PDi1 = 2 # Numer diva/rola - dla testów
        PDi2 = 2 # Numer użytkownika w divie - dla testów

        if float(PayDay) > 100:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys(myround(PayDay))
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        else:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr["""+ str(MinI)+ """]/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys("0")
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
        MinI = MinI + 1

    # Secretary

    
    path = """//*[@id="elSettingsTabs"]/div[1]/div/span[1]/span[2]"""
    Dotka1 = browser.find_element_by_xpath(path)
    path = """//*[@id="elSettingsTabs"]/div[1]/div/span[2]/span[2]"""
    Dotka2 = browser.find_element_by_xpath(path)

    path = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr/td[4]"""
    PaydayL = browser.find_element_by_xpath(path)
    path = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[4]"""
    PaydayA = browser.find_element_by_xpath(path)

    Nadmiar = float(Dotka1.text[1:][:-6]) - float(Dotka2.text[1:]) #add
    #Nadmiar = -800

    if Nadmiar > 0:
        Nadmiar = Nadmiar + float(PaydayL.text[1:])
        if Nadmiar > 800:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys("800")
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
            Nadmiar = Nadmiar - 800
        else:
            if Nadmiar < 800:
                search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr/td[6]/a[1]""")
                search_btn.click()
                time.sleep(2)
                search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                search_input.clear()
                search_input.send_keys(str(Nadmiar))
                time.sleep(2)
                search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                search_btn.click()
                time.sleep(2)
                Nadmiar = 0
            else:
                if Nadmiar == 800:
                    search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr/td[6]/a[1]""")
                    search_btn.click()
                    time.sleep(2)
                    search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                    search_input.clear()
                    search_input.send_keys("800")
                    time.sleep(2)
                    search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                    search_btn.click()
                    time.sleep(2)
                    Nadmiar = 0

    if Nadmiar > 0:
        Nadmiar = Nadmiar + float(PaydayA.text[1:])
        if Nadmiar > 800:
            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[6]/a[1]""")
            search_btn.click()
            time.sleep(2)
            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
            search_input.clear()
            search_input.send_keys("800")
            time.sleep(2)
            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
            search_btn.click()
            time.sleep(2)
            Nadmiar = Nadmiar - 800
        else:
            if Nadmiar < 800:
                search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[6]/a[1]""")
                search_btn.click()
                time.sleep(2)
                search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                search_input.clear()
                search_input.send_keys(str(Nadmiar))
                time.sleep(2)
                search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                search_btn.click()
                time.sleep(2)
                Nadmiar = 0
            else:
                if Nadmiar == 800:
                    search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[6]/a[1]""")
                    search_btn.click()
                    time.sleep(2)
                    search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                    search_input.clear()
                    search_input.send_keys("800")
                    time.sleep(2)
                    search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                    search_btn.click()
                    time.sleep(2)
                    Nadmiar = 0

    path1 = """//*[@id="elSettingsTabs"]/div[1]/div/span[1]/span[2]"""
    Data1 = browser.find_element_by_xpath(path1)
    path2 = """//*[@id="elSettingsTabs"]/div[1]/div/span[2]/span[2]"""
    Data2 = browser.find_element_by_xpath(path2)
    Dotka1 = Data1.text[1:][:4]
    Dotka2 = Data2.text[1:]
    print(Dotka1)
    print(Dotka2)
    
    Nadmiar = float(Dotka1) - float(Dotka2)
    #Nadmiar = -800
    if Nadmiar < 0:
        today1 = datetime.now() - timedelta(hours=4)
        today = '{:%Y, %m, %d}'.format(today1)
        today1 = datetime.now() - timedelta(hours=4)
        today3 = '{:%Y.%m.%d}'.format(today1)
        embed=discord.Embed(title="Zaległe wypłaty:" + " " + today3, url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
        Nadmiar = float(str(Nadmiar)[1:])
        print(Nadmiar)
        Roles = len(str(Role7).split()[7:][:-1])
        Rolesnr = Roles // 9
        i2 = 1
        for i in repeat(None, Rolesnr):
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[4]"""
            data = browser.find_element_by_xpath(path1)
            PD = float(data.text[1:])
            if Nadmiar > 0:
                webhook = DiscordWebhook(url= WebhookURL , content= "**" + str(today) + "**")
                response = webhook.execute()
                print("test0")
                if Nadmiar == PD:
                    Wypłata = 0
                    Nadmiar = 0
                    print("test1")
                    search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                    search_btn.click()
                    time.sleep(2)
                    search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                    search_input.clear()
                    search_input.send_keys(Wypłata)
                    time.sleep(2)
                    search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                    search_btn.click()
                    time.sleep(2)
                else:
                    if Nadmiar > PD: 
                        print("test2")
                        Wypłata = 0
                        Nadmiar = Nadmiar - PD
                        #dalej
                        search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                        search_btn.click()
                        time.sleep(2)
                        search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                        search_input.clear()
                        search_input.send_keys(Wypłata)
                        time.sleep(2)
                        search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                        search_btn.click()
                        time.sleep(2)
                    else:
                        if Nadmiar < PD:
                            Wypłata = PD - Nadmiar
                            Nadmiar = 0
                            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                            search_btn.click()
                            time.sleep(2)
                            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                            search_input.clear()
                            search_input.send_keys(Wypłata)
                            time.sleep(2)
                            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                            search_btn.click()
                            time.sleep(2)
                print(";3")
                print(Wypłata)

                path5 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[7]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[1]"""
                data = browser.find_element_by_xpath(path5)
                i2 = i2 +1

        Roles = len(str(Role8).split()[7:][:-1])
        Rolesnr = Roles // 9
        i2 = 1
        for i in repeat(None, Rolesnr):
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[6]/a[1]/i"""
            data = browser.find_element_by_xpath(path1)
            PD = float(data.text[1:])
            if Nadmiar > 0:
                webhook = DiscordWebhook(url= WebhookURL , content= "**" + str(today) + "**")
                response = webhook.execute()
                print("test0")
                if Nadmiar == PD:
                    Wypłata = 0
                    Nadmiar = 0
                    print("test1")
                    search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[6]/a[1]/i""")
                    search_btn.click()
                    time.sleep(2)
                    search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                    search_input.clear()
                    search_input.send_keys(Wypłata)
                    time.sleep(2)
                    search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                    search_btn.click()
                    time.sleep(2)
                else:
                    if Nadmiar > PD: 
                        print("test2")
                        Wypłata = 0
                        Nadmiar = Nadmiar - PD
                        #dalej
                        search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[6]/a[1]/i""")
                        search_btn.click()
                        time.sleep(2)
                        search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                        search_input.clear()
                        search_input.send_keys(Wypłata)
                        time.sleep(2)
                        search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                        search_btn.click()
                        time.sleep(2)
                    else:
                        if Nadmiar < PD:
                            Wypłata = PD - Nadmiar
                            Nadmiar = 0
                            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[6]/a[1]/i""")
                            search_btn.click()
                            time.sleep(2)
                            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                            search_input.clear()
                            search_input.send_keys(Wypłata)
                            time.sleep(2)
                            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                            search_btn.click()
                            time.sleep(2)
                print(";3")
                print(Wypłata)

                path5 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[6]/a[1]/i"""
                data = browser.find_element_by_xpath(path5)
                i2 = i2 +1

                path5 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[9]/div/div/div/table/tbody/tr/td[6]/a[1]/i"""
                data = browser.find_element_by_xpath(path5)

                zaległe = PD - Wypłata
                embed.add_field(name= data.text, value= str(zaległe) + "$" , inline=False)
                webhook = DiscordWebhook(url= WebhookURL , content= "**" + data.text + ":**" + " " + str(zaległe) + "$")
                if  zaległe > 0:
                    response = webhook.execute()
                i2 = i2 +1

        Roles = len(str(Role3).split()[7:][:-1])
        Rolesnr = Roles // 9
        i2 = 1
        for i in repeat(None, Rolesnr):
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[3]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[4]"""
            data = browser.find_element_by_xpath(path1)
            PD = float(data.text[1:])
            if Nadmiar > 0:
                if Nadmiar == PD:
                    Wypłata = 0
                    Nadmiar = 0
                    search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[3]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                    search_btn.click()
                    time.sleep(2)
                    search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                    search_input.clear()
                    search_input.send_keys(Wypłata)
                    time.sleep(2)
                    search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                    search_btn.click()
                    time.sleep(2)
                else:
                    if Nadmiar > PD: 
                        Wypłata = 0
                        Nadmiar = Nadmiar - PD
                        #dalej
                        search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[3]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                        search_btn.click()
                        time.sleep(2)
                        search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                        search_input.clear()
                        search_input.send_keys(Wypłata)
                        time.sleep(2)
                        search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                        search_btn.click()
                        time.sleep(2)
                    else:
                        if Nadmiar < PD:
                            Wypłata = PD - Nadmiar
                            Nadmiar = 0
                            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[3]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                            search_btn.click()
                            time.sleep(2)
                            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                            search_input.clear()
                            search_input.send_keys(Wypłata)
                            time.sleep(2)
                            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                            search_btn.click()
                            time.sleep(2)
                print(";3")
                print(Wypłata)

                path5 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[3]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[1]"""
                data = browser.find_element_by_xpath(path5)

                zaległe = PD - Wypłata
                embed.add_field(name= data.text, value= str(zaległe) + "$" , inline=False)
                webhook = DiscordWebhook(url= WebhookURL , content= "**" + data.text + ":**" + " " + str(zaległe) + "$")
                if  zaległe > 0:
                    response = webhook.execute()
                i2 = i2 +1
            

        # Secretary


        Roles = len(str(Role4).split()[7:][:-1])
        Rolesnr = Roles // 9
        i2 = 1
        for i in repeat(None, Rolesnr):
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[4]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[4]"""
            data = browser.find_element_by_xpath(path1)
            PD = float(data.text[1:])
            if Nadmiar > 0:
                if Nadmiar == PD:
                    Wypłata = 0
                    Nadmiar = 0
                    search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[4]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                    search_btn.click()
                    time.sleep(2)
                    search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                    search_input.clear()
                    search_input.send_keys(Wypłata)
                    time.sleep(2)
                    search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                    search_btn.click()
                    time.sleep(2)
                else:
                    if Nadmiar > PD: 
                        Wypłata = 0
                        Nadmiar = Nadmiar - PD
                        #dalej
                        search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[4]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                        search_btn.click()
                        time.sleep(2)
                        search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                        search_input.clear()
                        search_input.send_keys(Wypłata)
                        time.sleep(2)
                        search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                        search_btn.click()
                        time.sleep(2)
                    else:
                        if Nadmiar < PD:
                            Wypłata = PD - Nadmiar
                            Nadmiar = 0
                            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[4]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                            search_btn.click()
                            time.sleep(2)
                            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                            search_input.clear()
                            search_input.send_keys(Wypłata)
                            time.sleep(2)
                            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                            search_btn.click()
                            time.sleep(2)
                print(";3")
                print(Wypłata)

                path5 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[4]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[1]"""
                data = browser.find_element_by_xpath(path5)

                zaległe = PD - Wypłata
                embed.add_field(name= data.text, value= str(zaległe) + "$" , inline=False)
                webhook = DiscordWebhook(url= WebhookURL , content= "**" + data.text + ":**" + " " + str(zaległe) + "$")
                if  zaległe > 0:
                    response = webhook.execute()
                i2 = i2 +1


        Roles = len(str(Role5).split()[7:][:-1])
        Rolesnr = Roles // 9
        i2 = 1
        for i in repeat(None, Rolesnr):
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[5]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[4]"""
            data = browser.find_element_by_xpath(path1)
            PD = float(data.text[1:])
            if Nadmiar > 0:
                if Nadmiar == PD:
                    Wypłata = 0
                    Nadmiar = 0
                    search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[5]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                    search_btn.click()
                    time.sleep(2)
                    search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                    search_input.clear()
                    search_input.send_keys(Wypłata)
                    time.sleep(2)
                    search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                    search_btn.click()
                    time.sleep(2)
                else:
                    if Nadmiar > PD: 
                        Wypłata = 0
                        Nadmiar = Nadmiar - PD
                        #dalej
                        search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[5]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                        search_btn.click()
                        time.sleep(2)
                        search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                        search_input.clear()
                        search_input.send_keys(Wypłata)
                        time.sleep(2)
                        search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                        search_btn.click()
                        time.sleep(2)
                    else:
                        if Nadmiar < PD:
                            Wypłata = PD - Nadmiar
                            Nadmiar = 0
                            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[5]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                            search_btn.click()
                            time.sleep(2)
                            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                            search_input.clear()
                            search_input.send_keys(Wypłata)
                            time.sleep(2)
                            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                            search_btn.click()
                            time.sleep(2)
                print(";3")
                print(Wypłata)

                path5 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[5]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[1]"""
                data = browser.find_element_by_xpath(path5)

                zaległe = PD - Wypłata
                embed.add_field(name= data.text, value= str(zaległe) + "$" , inline=False)
                webhook = DiscordWebhook(url= WebhookURL , content= "**" + data.text + ":**" + " " + str(zaległe) + "$")
                if  zaległe > 0:
                    response = webhook.execute()
                i2 = i2 +1


        Roles = len(str(Role6).split()[7:][:-1])
        Rolesnr = Roles // 9
        i2 = 1
        for i in repeat(None, Rolesnr):
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[6]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[4]"""
            data = browser.find_element_by_xpath(path1)
            PD = float(data.text[1:])
            if Nadmiar > 0:
                if Nadmiar == PD:
                    Wypłata = 0
                    Nadmiar = 0
                    search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[6]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                    search_btn.click()
                    time.sleep(2)
                    search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                    search_input.clear()
                    search_input.send_keys(Wypłata)
                    time.sleep(2)
                    search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                    search_btn.click()
                    time.sleep(2)
                else:
                    if Nadmiar > PD: 
                        Wypłata = 0
                        Nadmiar = Nadmiar - PD
                        #dalej
                        search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[6]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                        search_btn.click()
                        time.sleep(2)
                        search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                        search_input.clear()
                        search_input.send_keys(Wypłata)
                        time.sleep(2)
                        search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                        search_btn.click()
                        time.sleep(2)
                    else:
                        if Nadmiar < PD:
                            Wypłata = PD - Nadmiar
                            Nadmiar = 0
                            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[6]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                            search_btn.click()
                            time.sleep(2)
                            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                            search_input.clear()
                            search_input.send_keys(Wypłata)
                            time.sleep(2)
                            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                            search_btn.click()
                            time.sleep(2)
                print(";3")
                print(Wypłata)

                path5 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[6]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[1]"""
                data = browser.find_element_by_xpath(path5)

                zaległe = PD - Wypłata
                embed.add_field(name= data.text, value= str(zaległe) + "$" , inline=False)
                webhook = DiscordWebhook(url= WebhookURL , content= "**" + data.text + ":**" + " " + str(zaległe) + "$")
                if  zaległe > 0:
                    response = webhook.execute()
                i2 = i2 +1



        Roles = len(str(Role2).split()[7:][:-1])
        Rolesnr = Roles // 9
        i2 = 1
        for i in repeat(None, Rolesnr):
            path1 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[2]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[4]"""
            data = browser.find_element_by_xpath(path1)
            PD = float(data.text[1:])
            if Nadmiar > 0:
                if Nadmiar == PD:
                    Wypłata = 0
                    Nadmiar = 0
                    search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[2]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                    search_btn.click()
                    time.sleep(2)
                    search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                    search_input.clear()
                    search_input.send_keys(Wypłata)
                    time.sleep(2)
                    search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                    search_btn.click()
                    time.sleep(2)
                else:
                    if Nadmiar > PD: 
                        Wypłata = 0
                        Nadmiar = Nadmiar - PD
                        #dalej
                        search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[2]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                        search_btn.click()
                        time.sleep(2)
                        search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                        search_input.clear()
                        search_input.send_keys(Wypłata)
                        time.sleep(2)
                        search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                        search_btn.click()
                        time.sleep(2)
                    else:
                        if Nadmiar < PD:
                            Wypłata = PD - Nadmiar
                            Nadmiar = 0
                            search_btn = browser.find_element_by_xpath("""//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[2]/div/div/div/table/tbody/tr["""+ str(i2)+ """]/td[6]/a[1]""")
                            search_btn.click()
                            time.sleep(2)
                            search_input = browser.find_element_by_xpath("""//*[@id="form_payday"]/div/input""")
                            search_input.clear()
                            search_input.send_keys(Wypłata)
                            time.sleep(2)
                            search_btn = browser.find_element_by_xpath("//button[text()='Zapisz']")
                            search_btn.click()
                            time.sleep(2)
                print(";3")
                print(Wypłata)


                path5 = """//*[@id="ipsTabs_elSettingsTabs_setting_dashboard_panel"]/div/div[2]/div/div/div/table/tbody/tr["""+ str(i2) +"""]/td[1]"""
                data = browser.find_element_by_xpath(path5)

                zaległe = PD - Wypłata
                embed.add_field(name= data.text, value= str(zaległe) + "$" , inline=False)
                webhook = DiscordWebhook(url= WebhookURL , content= "**" + data.text + ":**" + " " + str(zaległe) + "$")
                if  zaległe > 0:
                    response = webhook.execute()
                i2 = i2 +1
        
                    

@client.command()
async def old(ctx, arg1):
    mycursor = mydb.cursor()
    print(arg1)
    datetime.strptime(arg1, "%d.%m.%Y")
    mycursor.execute("SHOW TABLES WHERE Tables_in_mydatabase = '" + arg1 + "'")
    Exist = 0

    for x in mycursor: 
        Exist = 1
        mycursor.execute("SELECT nick, Ofki, minut, zysk FROM `" + arg1 + "` WHERE ranga = 'CEO' OR ranga = 'VCEO' OR ranga = 'Director' OR ranga = 'Menager'")
        myresult = mycursor.fetchall()
        embed=discord.Embed(title="Zarząd główny", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
        for x in myresult:
            embed.add_field(name= x[0] , value="**MIN:**" + " " + x[2] + " " + "**O:**" + " " + x[1] + " " + "**Z:**" + " " + x[3], inline=False)
        await ctx.send(embed=embed)

            # Secretary

        mycursor.execute("SELECT nick, Ofki, minut, zysk FROM `" + arg1 + "` WHERE ranga = 'Supervisor'")
        myresult = mycursor.fetchall()
        embed=discord.Embed(title="Supervisor", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
        for x in myresult:
            embed.add_field(name= x[0] , value="**MIN:**" + " " + x[2] + " " + "**O:**" + " " + x[1] + " " + "**Z:**" + " " + x[3], inline=False)
        await ctx.send(embed=embed)

        mycursor.execute("SELECT nick, Ofki, minut, zysk FROM `" + arg1 + "` WHERE ranga = 'Boulanger'")
        myresult = mycursor.fetchall()
        embed=discord.Embed(title="Boulanger", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
        for x in myresult:
            embed.add_field(name= x[0] , value="**MIN:**" + " " + x[2] + " " + "**O:**" + " " + x[1] + " " + "**Z:**" + " " + x[3], inline=False)
        await ctx.send(embed=embed)

        mycursor.execute("SELECT nick, Ofki, minut, zysk FROM `" + arg1 + "` WHERE ranga = 'Commis'")
        myresult = mycursor.fetchall()
        embed=discord.Embed(title="Commis", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
        for x in myresult:
            embed.add_field(name= x[0] , value="**MIN:**" + " " + x[2] + " " + "**O:**" + " " + x[1] + " " + "**Z:**" + " " + x[3], inline=False)
        await ctx.send(embed=embed)

        mycursor.execute("SELECT nick, Ofki, minut, zysk FROM `" + arg1 + "` WHERE ranga = 'Apprentice'")
        myresult = mycursor.fetchall()
        embed=discord.Embed(title="Apprentice", url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
        for x in myresult:
            embed.add_field(name= x[0] , value="**MIN:**" + " " + x[2] + " " + "**O:**" + " " + x[1] + " " + "**Z:**" + " " + x[3], inline=False)
        await ctx.send(embed=embed)

    if Exist == 0:
        await ctx.send("Brak danych z danego dnia.")
    print(arg1)

@client.command()
async def stats(ctx, arg1):
    embed=discord.Embed(title="Statystyki całkowite z dnia:" + " " + arg1, url="https://devgaming.pl/index.php?app=devgaming&module=groups&controller=panel&area=dashboard&character=220462&group=2874", color=0xFF5733)
    mycursor = mydb.cursor()
    datetime.strptime(arg1, "%d.%m.%Y")
    mycursor.execute("SELECT nick, Ofki, minut, zysk FROM `" + arg1 + "`")
    myresult = mycursor.fetchall()
    Exist = 0
    ofki = 0
    minuty = 0
    zysk = 0
    for x in myresult:
        arg2 = datetime.strptime(arg1, "%d.%m.%Y").strftime("%Y, %m, %d")
        Exist = 1
        amount = len(myresult)
        ofki = ofki + float(x[1])
        minuty = minuty + float(x[2][:-4])
        zysk = zysk + float(x[3][:-1])
        mycursor.execute("SELECT Ofki FROM wykresy WHERE data = '" + arg2 + " 15' AND Godzina = 15")

        myresult = mycursor.fetchall()
        godzina1 = 0
        godzina2 = 0
        godzina3 = 0
        godzina4 = 0
        godzina5 = 0
        godzina6 = 0
        godzina7 = 0
        godzina8 = 0
        godzina9 = 0

        for x in myresult:
            godzina1 = x[0]
            print(godzina1)

        mycursor.execute("SELECT Ofki FROM wykresy WHERE data = '" + arg2 + " 16' AND Godzina = 16")

        myresult = mycursor.fetchall()

        for x in myresult:
            godzina2 = x[0]
            print(godzina2)

        mycursor.execute("SELECT Ofki FROM wykresy WHERE data = '" + arg2 + " 17' AND Godzina = 17")

        myresult = mycursor.fetchall()

        for x in myresult:
            godzina3 = x[0]
            print(godzina3)

        mycursor.execute("SELECT Ofki FROM wykresy WHERE data = '" + arg2 + " 18' AND Godzina = 18")

        myresult = mycursor.fetchall()

        for x in myresult:
            godzina4 = x[0]
            print(godzina4)

        mycursor.execute("SELECT Ofki FROM wykresy WHERE data = '" + arg2 + " 19' AND Godzina = 19")

        myresult = mycursor.fetchall()

        for x in myresult:
            godzina5 = x[0]
            print(godzina5)

        mycursor.execute("SELECT Ofki FROM wykresy WHERE data = '" + arg2 + " 20' AND Godzina = 20")

        myresult = mycursor.fetchall()

        for x in myresult:
            godzina6 = x[0]
            print(godzina6)

        mycursor.execute("SELECT Ofki FROM wykresy WHERE data = '" + arg2 + " 21' AND Godzina = 21")

        myresult = mycursor.fetchall()

        for x in myresult:
            godzina7 = x[0]
            print(godzina7)

        mycursor.execute("SELECT Ofki FROM wykresy WHERE data = '" + arg2 + " 22' AND Godzina = 22")

        myresult = mycursor.fetchall()

        for x in myresult:
            godzina8 = x[0]
            print(godzina8)

        mycursor.execute("SELECT Ofki FROM wykresy WHERE data = '" + arg2 + " 23' AND Godzina = 23")

        myresult = mycursor.fetchall()

        for x in myresult:
            godzina9 = x[0]
            print(godzina9)

        Godzina = ["15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"]
        Ofki = [float(godzina1),float(godzina2),float(godzina3),float(godzina4),float(godzina5),float(godzina6),float(godzina7),float(godzina8),float(godzina9)]
        plt.plot(Godzina, Ofki, color='red', marker='o')
        plt.title('Wykres ofert')
        plt.xlabel('Godzina')
        plt.ylabel('Ofki')
        plt.grid(True) 

        plt.savefig('ofki.png')
    embed.add_field(name= "Statystyki podstawowe:", value="**MIN:**" + " " + str(round(minuty)) + " " + "**O:**" + " " + str(round(ofki)) + " " + "**Z:**" + " " + str(round(zysk)) + "$", inline=False)
    file = discord.File("ofki.png")
    await ctx.send(embed=embed)
    await ctx.send(file = file)
    if Exist == 0:
        await ctx.send("Brak danych z danego dnia.")


client.run(TOKEN)

