var = "MitsusBishi1234567890"
print(var[:10])